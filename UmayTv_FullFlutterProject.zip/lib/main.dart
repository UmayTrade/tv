
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

void main() {
  runApp(const UmayTvApp());
}

class UmayTvApp extends StatelessWidget {
  const UmayTvApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UmayTv',
      theme: ThemeData.dark(useMaterial3: true),
      home: const ChannelListScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Channel {
  final String name;
  final String url;
  final String category;

  Channel({required this.name, required this.url, this.category = "Genel"});
}

class ChannelListScreen extends StatefulWidget {
  const ChannelListScreen({super.key});

  @override
  State<ChannelListScreen> createState() => _ChannelListScreenState();
}

class _ChannelListScreenState extends State<ChannelListScreen> {
  List<Channel> channels = [];
  List<String> favorites = [];
  String selectedCategory = "Tümü";

  @override
  void initState() {
    super.initState();
    loadFavorites();
    loadChannels();
  }

  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      favorites = prefs.getStringList('favorites') ?? [];
    });
  }

  Future<void> toggleFavorite(String url) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (favorites.contains(url)) {
        favorites.remove(url);
      } else {
        favorites.add(url);
      }
      prefs.setStringList('favorites', favorites);
    });
  }

  Future<void> loadChannels() async {
    final response = await http.get(Uri.parse('https://raw.githubusercontent.com/UmayTrade/tv/refs/heads/main/hrbsy.m3u'));
    if (response.statusCode == 200) {
      final lines = response.body.split('
');
      String? name;
      String? url;
      String category = "Genel";
      for (var line in lines) {
        if (line.startsWith('#EXTINF')) {
          name = line.split(',').last.trim();
          if (line.toLowerCase().contains("film")) category = "Film";
          else if (line.toLowerCase().contains("spor")) category = "Spor";
          else if (line.toLowerCase().contains("çocuk")) category = "Çocuk";
          else category = "Genel";
        } else if (line.startsWith('http') && name != null) {
          url = line.trim();
          channels.add(Channel(name: name, url: url, category: category));
          name = null;
        }
      }
      setState(() {});
    }
  }

  List<String> get categories {
    return ["Tümü", ...{for (var c in channels) c.category}];
  }

  @override
  Widget build(BuildContext context) {
    List<Channel> filtered = selectedCategory == "Tümü"
        ? channels
        : channels.where((c) => c.category == selectedCategory).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('UmayTv'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: DropdownButton<String>(
              value: selectedCategory,
              dropdownColor: Colors.grey[900],
              onChanged: (value) {
                if (value != null) {
                  setState(() {
                    selectedCategory = value;
                  });
                }
              },
              items: categories
                  .map((cat) => DropdownMenuItem(value: cat, child: Text(cat)))
                  .toList(),
            ),
          ),
        ],
      ),
      body: filtered.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final channel = filtered[index];
                final isFav = favorites.contains(channel.url);
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(channel.name),
                    subtitle: Text(channel.category),
                    trailing: IconButton(
                      icon: Icon(isFav ? Icons.favorite : Icons.favorite_border,
                          color: isFav ? Colors.red : Colors.grey),
                      onPressed: () => toggleFavorite(channel.url),
                    ),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChannelDetailScreen(channel: channel),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class ChannelDetailScreen extends StatelessWidget {
  final Channel channel;

  const ChannelDetailScreen({required this.channel, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(channel.name)),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 16),
          Text("Kategori: ${channel.category}", style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 16),
          Expanded(child: VideoPlayerWidget(url: channel.url)),
        ],
      ),
    );
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String url;

  const VideoPlayerWidget({super.key, required this.url});

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    final stopwatch = Stopwatch()..start();
    _controller = VideoPlayerController.network(widget.url)
      ..initialize().then((_) {
        stopwatch.stop();
        print("Load time: ${stopwatch.elapsedMilliseconds}ms");
        setState(() {
          _loading = false;
          _controller.play();
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _loading
          ? const CircularProgressIndicator()
          : AspectRatio(
              aspectRatio: _controller.value.aspectRatio,
              child: VideoPlayer(_controller),
            ),
    );
  }
}
